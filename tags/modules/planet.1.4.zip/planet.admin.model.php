<?php
	/**
	 * @class  planetAdminModel
	 * @author sol (sol@ngleader.com)
	 * @version 0.1
	 * @brief  planet 모듈의 admin model class
	 **/

	class planetAdminModel extends planet {

		/**
		 * @brief 초기화
		 **/
		function init() {
		}

	}
?>
